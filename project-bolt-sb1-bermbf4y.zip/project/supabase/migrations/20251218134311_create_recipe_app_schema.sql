/*
  # Recipe Generator & Meal Planner Database Schema

  ## Overview
  This migration creates the complete database schema for an AI-powered recipe generator and meal planner application.

  ## New Tables

  1. **profiles**
     - `id` (uuid, references auth.users)
     - `email` (text)
     - `full_name` (text)
     - `avatar_url` (text)
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  2. **dietary_preferences**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles)
     - `preference_type` (text) - e.g., 'vegetarian', 'vegan', 'gluten-free', 'keto', etc.
     - `is_active` (boolean)
     - `created_at` (timestamptz)

  3. **nutrition_goals**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles)
     - `daily_calories` (integer)
     - `daily_protein_g` (integer)
     - `daily_carbs_g` (integer)
     - `daily_fat_g` (integer)
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  4. **recipes**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles) - creator
     - `title` (text)
     - `description` (text)
     - `instructions` (text)
     - `prep_time_minutes` (integer)
     - `cook_time_minutes` (integer)
     - `servings` (integer)
     - `calories_per_serving` (integer)
     - `protein_g` (integer)
     - `carbs_g` (integer)
     - `fat_g` (integer)
     - `image_url` (text)
     - `is_ai_generated` (boolean)
     - `cuisine_type` (text)
     - `difficulty_level` (text)
     - `tags` (text[])
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  5. **ingredients**
     - `id` (uuid, primary key)
     - `name` (text, unique)
     - `category` (text)
     - `calories_per_100g` (integer)
     - `protein_per_100g` (decimal)
     - `carbs_per_100g` (decimal)
     - `fat_per_100g` (decimal)
     - `created_at` (timestamptz)

  6. **recipe_ingredients**
     - `id` (uuid, primary key)
     - `recipe_id` (uuid, references recipes)
     - `ingredient_id` (uuid, references ingredients)
     - `quantity` (decimal)
     - `unit` (text)
     - `notes` (text)

  7. **user_inventory**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles)
     - `ingredient_id` (uuid, references ingredients)
     - `quantity` (decimal)
     - `unit` (text)
     - `expiry_date` (date)
     - `created_at` (timestamptz)
     - `updated_at` (timestamptz)

  8. **meal_plans**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles)
     - `date` (date)
     - `meal_type` (text) - 'breakfast', 'lunch', 'dinner', 'snack'
     - `recipe_id` (uuid, references recipes)
     - `servings` (integer)
     - `notes` (text)
     - `created_at` (timestamptz)

  9. **shopping_lists**
     - `id` (uuid, primary key)
     - `user_id` (uuid, references profiles)
     - `ingredient_id` (uuid, references ingredients)
     - `quantity` (decimal)
     - `unit` (text)
     - `is_purchased` (boolean)
     - `notes` (text)
     - `created_at` (timestamptz)

  10. **recipe_ratings**
      - `id` (uuid, primary key)
      - `recipe_id` (uuid, references recipes)
      - `user_id` (uuid, references profiles)
      - `rating` (integer) - 1-5 stars
      - `review` (text)
      - `created_at` (timestamptz)

  ## Security
  - Enable RLS on all tables
  - Users can only access their own data
  - Recipes are readable by all authenticated users
  - Users can only modify their own recipes, meal plans, and shopping lists

  ## Indexes
  - Add indexes for frequently queried columns
  - Optimize recipe search by tags and cuisine type
*/

-- Create profiles table
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users ON DELETE CASCADE,
  email text UNIQUE NOT NULL,
  full_name text,
  avatar_url text,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create dietary preferences table
CREATE TABLE IF NOT EXISTS dietary_preferences (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  preference_type text NOT NULL,
  is_active boolean DEFAULT true,
  created_at timestamptz DEFAULT now()
);

-- Create nutrition goals table
CREATE TABLE IF NOT EXISTS nutrition_goals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  daily_calories integer DEFAULT 2000,
  daily_protein_g integer DEFAULT 50,
  daily_carbs_g integer DEFAULT 250,
  daily_fat_g integer DEFAULT 70,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create ingredients table
CREATE TABLE IF NOT EXISTS ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text UNIQUE NOT NULL,
  category text DEFAULT 'other',
  calories_per_100g integer DEFAULT 0,
  protein_per_100g decimal(5,2) DEFAULT 0,
  carbs_per_100g decimal(5,2) DEFAULT 0,
  fat_per_100g decimal(5,2) DEFAULT 0,
  created_at timestamptz DEFAULT now()
);

-- Create recipes table
CREATE TABLE IF NOT EXISTS recipes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  title text NOT NULL,
  description text DEFAULT '',
  instructions text DEFAULT '',
  prep_time_minutes integer DEFAULT 0,
  cook_time_minutes integer DEFAULT 0,
  servings integer DEFAULT 1,
  calories_per_serving integer DEFAULT 0,
  protein_g integer DEFAULT 0,
  carbs_g integer DEFAULT 0,
  fat_g integer DEFAULT 0,
  image_url text,
  is_ai_generated boolean DEFAULT false,
  cuisine_type text DEFAULT 'other',
  difficulty_level text DEFAULT 'medium',
  tags text[] DEFAULT '{}',
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create recipe ingredients junction table
CREATE TABLE IF NOT EXISTS recipe_ingredients (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id uuid REFERENCES recipes(id) ON DELETE CASCADE NOT NULL,
  ingredient_id uuid REFERENCES ingredients(id) ON DELETE CASCADE NOT NULL,
  quantity decimal(10,2) NOT NULL,
  unit text NOT NULL,
  notes text DEFAULT ''
);

-- Create user inventory table
CREATE TABLE IF NOT EXISTS user_inventory (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  ingredient_id uuid REFERENCES ingredients(id) ON DELETE CASCADE NOT NULL,
  quantity decimal(10,2) NOT NULL,
  unit text NOT NULL,
  expiry_date date,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

-- Create meal plans table
CREATE TABLE IF NOT EXISTS meal_plans (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  date date NOT NULL,
  meal_type text NOT NULL,
  recipe_id uuid REFERENCES recipes(id) ON DELETE CASCADE NOT NULL,
  servings integer DEFAULT 1,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create shopping lists table
CREATE TABLE IF NOT EXISTS shopping_lists (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  ingredient_id uuid REFERENCES ingredients(id) ON DELETE CASCADE NOT NULL,
  quantity decimal(10,2) NOT NULL,
  unit text NOT NULL,
  is_purchased boolean DEFAULT false,
  notes text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

-- Create recipe ratings table
CREATE TABLE IF NOT EXISTS recipe_ratings (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  recipe_id uuid REFERENCES recipes(id) ON DELETE CASCADE NOT NULL,
  user_id uuid REFERENCES profiles(id) ON DELETE CASCADE NOT NULL,
  rating integer NOT NULL CHECK (rating >= 1 AND rating <= 5),
  review text DEFAULT '',
  created_at timestamptz DEFAULT now(),
  UNIQUE(recipe_id, user_id)
);

-- Create indexes for better query performance
CREATE INDEX IF NOT EXISTS idx_recipes_user_id ON recipes(user_id);
CREATE INDEX IF NOT EXISTS idx_recipes_cuisine_type ON recipes(cuisine_type);
CREATE INDEX IF NOT EXISTS idx_recipes_tags ON recipes USING gin(tags);
CREATE INDEX IF NOT EXISTS idx_meal_plans_user_date ON meal_plans(user_id, date);
CREATE INDEX IF NOT EXISTS idx_shopping_lists_user ON shopping_lists(user_id);
CREATE INDEX IF NOT EXISTS idx_dietary_preferences_user ON dietary_preferences(user_id);

-- Enable Row Level Security
ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;
ALTER TABLE dietary_preferences ENABLE ROW LEVEL SECURITY;
ALTER TABLE nutrition_goals ENABLE ROW LEVEL SECURITY;
ALTER TABLE ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE recipes ENABLE ROW LEVEL SECURITY;
ALTER TABLE recipe_ingredients ENABLE ROW LEVEL SECURITY;
ALTER TABLE user_inventory ENABLE ROW LEVEL SECURITY;
ALTER TABLE meal_plans ENABLE ROW LEVEL SECURITY;
ALTER TABLE shopping_lists ENABLE ROW LEVEL SECURITY;
ALTER TABLE recipe_ratings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for profiles
CREATE POLICY "Users can view own profile"
  ON profiles FOR SELECT
  TO authenticated
  USING (auth.uid() = id);

CREATE POLICY "Users can update own profile"
  ON profiles FOR UPDATE
  TO authenticated
  USING (auth.uid() = id)
  WITH CHECK (auth.uid() = id);

CREATE POLICY "Users can insert own profile"
  ON profiles FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = id);

-- RLS Policies for dietary preferences
CREATE POLICY "Users can view own dietary preferences"
  ON dietary_preferences FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own dietary preferences"
  ON dietary_preferences FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own dietary preferences"
  ON dietary_preferences FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own dietary preferences"
  ON dietary_preferences FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for nutrition goals
CREATE POLICY "Users can view own nutrition goals"
  ON nutrition_goals FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own nutrition goals"
  ON nutrition_goals FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own nutrition goals"
  ON nutrition_goals FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

-- RLS Policies for ingredients (readable by all authenticated users)
CREATE POLICY "Authenticated users can view ingredients"
  ON ingredients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Authenticated users can insert ingredients"
  ON ingredients FOR INSERT
  TO authenticated
  WITH CHECK (true);

-- RLS Policies for recipes
CREATE POLICY "Authenticated users can view all recipes"
  ON recipes FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own recipes"
  ON recipes FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own recipes"
  ON recipes FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own recipes"
  ON recipes FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for recipe ingredients
CREATE POLICY "Authenticated users can view recipe ingredients"
  ON recipe_ingredients FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can manage recipe ingredients for own recipes"
  ON recipe_ingredients FOR INSERT
  TO authenticated
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM recipes
      WHERE recipes.id = recipe_ingredients.recipe_id
      AND recipes.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can update recipe ingredients for own recipes"
  ON recipe_ingredients FOR UPDATE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM recipes
      WHERE recipes.id = recipe_ingredients.recipe_id
      AND recipes.user_id = auth.uid()
    )
  )
  WITH CHECK (
    EXISTS (
      SELECT 1 FROM recipes
      WHERE recipes.id = recipe_ingredients.recipe_id
      AND recipes.user_id = auth.uid()
    )
  );

CREATE POLICY "Users can delete recipe ingredients for own recipes"
  ON recipe_ingredients FOR DELETE
  TO authenticated
  USING (
    EXISTS (
      SELECT 1 FROM recipes
      WHERE recipes.id = recipe_ingredients.recipe_id
      AND recipes.user_id = auth.uid()
    )
  );

-- RLS Policies for user inventory
CREATE POLICY "Users can view own inventory"
  ON user_inventory FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own inventory"
  ON user_inventory FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own inventory"
  ON user_inventory FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own inventory"
  ON user_inventory FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for meal plans
CREATE POLICY "Users can view own meal plans"
  ON meal_plans FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own meal plans"
  ON meal_plans FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own meal plans"
  ON meal_plans FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own meal plans"
  ON meal_plans FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for shopping lists
CREATE POLICY "Users can view own shopping lists"
  ON shopping_lists FOR SELECT
  TO authenticated
  USING (auth.uid() = user_id);

CREATE POLICY "Users can insert own shopping lists"
  ON shopping_lists FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own shopping lists"
  ON shopping_lists FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own shopping lists"
  ON shopping_lists FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);

-- RLS Policies for recipe ratings
CREATE POLICY "Authenticated users can view all ratings"
  ON recipe_ratings FOR SELECT
  TO authenticated
  USING (true);

CREATE POLICY "Users can insert own ratings"
  ON recipe_ratings FOR INSERT
  TO authenticated
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can update own ratings"
  ON recipe_ratings FOR UPDATE
  TO authenticated
  USING (auth.uid() = user_id)
  WITH CHECK (auth.uid() = user_id);

CREATE POLICY "Users can delete own ratings"
  ON recipe_ratings FOR DELETE
  TO authenticated
  USING (auth.uid() = user_id);