/*
  # Seed Common Ingredients

  ## Overview
  This migration populates the ingredients table with common ingredients used in cooking,
  along with their nutritional information per 100g.

  ## Ingredients Added
  - Proteins: chicken breast, ground beef, salmon, eggs, tofu
  - Dairy: milk, cheese, yogurt, butter
  - Vegetables: tomatoes, onions, garlic, bell peppers, carrots, broccoli, spinach
  - Fruits: bananas, apples, berries
  - Grains: rice, pasta, bread, oats
  - Seasonings: salt, pepper, olive oil
  - Legumes: black beans, chickpeas, lentils
*/

INSERT INTO ingredients (name, category, calories_per_100g, protein_per_100g, carbs_per_100g, fat_per_100g)
VALUES
  -- Proteins
  ('chicken breast', 'protein', 165, 31.0, 0.0, 3.6),
  ('ground beef', 'protein', 250, 26.0, 0.0, 15.0),
  ('salmon', 'protein', 208, 20.0, 0.0, 13.0),
  ('eggs', 'protein', 155, 13.0, 1.1, 11.0),
  ('tofu', 'protein', 76, 8.0, 1.9, 4.8),
  ('shrimp', 'protein', 99, 24.0, 0.2, 0.3),
  
  -- Dairy
  ('milk', 'dairy', 42, 3.4, 5.0, 1.0),
  ('cheddar cheese', 'dairy', 403, 25.0, 1.3, 33.0),
  ('yogurt', 'dairy', 59, 10.0, 3.6, 0.4),
  ('butter', 'dairy', 717, 0.9, 0.1, 81.0),
  ('cream', 'dairy', 340, 2.1, 2.7, 37.0),
  
  -- Vegetables
  ('tomatoes', 'vegetable', 18, 0.9, 3.9, 0.2),
  ('onions', 'vegetable', 40, 1.1, 9.3, 0.1),
  ('garlic', 'vegetable', 149, 6.4, 33.0, 0.5),
  ('bell peppers', 'vegetable', 20, 0.9, 4.6, 0.2),
  ('carrots', 'vegetable', 41, 0.9, 9.6, 0.2),
  ('broccoli', 'vegetable', 34, 2.8, 7.0, 0.4),
  ('spinach', 'vegetable', 23, 2.9, 3.6, 0.4),
  ('potatoes', 'vegetable', 77, 2.0, 17.0, 0.1),
  ('sweet potatoes', 'vegetable', 86, 1.6, 20.0, 0.1),
  ('lettuce', 'vegetable', 15, 1.4, 2.9, 0.2),
  ('mushrooms', 'vegetable', 22, 3.1, 3.3, 0.3),
  ('zucchini', 'vegetable', 17, 1.2, 3.1, 0.3),
  ('cucumber', 'vegetable', 15, 0.7, 3.6, 0.1),
  
  -- Fruits
  ('bananas', 'fruit', 89, 1.1, 22.8, 0.3),
  ('apples', 'fruit', 52, 0.3, 14.0, 0.2),
  ('blueberries', 'fruit', 57, 0.7, 14.5, 0.3),
  ('strawberries', 'fruit', 32, 0.7, 7.7, 0.3),
  ('oranges', 'fruit', 47, 0.9, 11.8, 0.1),
  ('avocado', 'fruit', 160, 2.0, 8.5, 14.7),
  ('lemons', 'fruit', 29, 1.1, 9.3, 0.3),
  
  -- Grains & Carbs
  ('white rice', 'grain', 130, 2.7, 28.0, 0.3),
  ('brown rice', 'grain', 111, 2.6, 23.0, 0.9),
  ('pasta', 'grain', 131, 5.0, 25.0, 1.1),
  ('bread', 'grain', 265, 9.0, 49.0, 3.2),
  ('oats', 'grain', 389, 16.9, 66.3, 6.9),
  ('quinoa', 'grain', 120, 4.4, 21.3, 1.9),
  
  -- Legumes
  ('black beans', 'legume', 132, 8.9, 23.7, 0.5),
  ('chickpeas', 'legume', 164, 8.9, 27.4, 2.6),
  ('lentils', 'legume', 116, 9.0, 20.0, 0.4),
  ('kidney beans', 'legume', 127, 8.7, 22.8, 0.5),
  
  -- Seasonings & Oils
  ('olive oil', 'oil', 884, 0.0, 0.0, 100.0),
  ('vegetable oil', 'oil', 884, 0.0, 0.0, 100.0),
  ('salt', 'seasoning', 0, 0.0, 0.0, 0.0),
  ('black pepper', 'seasoning', 251, 10.4, 64.0, 3.3),
  ('soy sauce', 'seasoning', 53, 5.6, 4.9, 0.1),
  ('honey', 'sweetener', 304, 0.3, 82.4, 0.0),
  ('sugar', 'sweetener', 387, 0.0, 100.0, 0.0),
  
  -- Nuts & Seeds
  ('almonds', 'nut', 579, 21.0, 22.0, 50.0),
  ('walnuts', 'nut', 654, 15.0, 14.0, 65.0),
  ('peanut butter', 'nut', 588, 25.0, 20.0, 50.0),
  ('chia seeds', 'seed', 486, 16.5, 42.1, 30.7),
  
  -- Herbs
  ('basil', 'herb', 23, 3.2, 2.7, 0.6),
  ('cilantro', 'herb', 23, 2.1, 3.7, 0.5),
  ('parsley', 'herb', 36, 3.0, 6.3, 0.8),
  ('thyme', 'herb', 101, 5.6, 24.0, 1.7),
  ('rosemary', 'herb', 131, 3.3, 20.7, 5.9)
ON CONFLICT (name) DO NOTHING;
