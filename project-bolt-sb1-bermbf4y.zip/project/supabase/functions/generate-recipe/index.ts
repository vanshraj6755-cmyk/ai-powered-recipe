import "jsr:@supabase/functions-js/edge-runtime.d.ts";

const corsHeaders = {
  "Access-Control-Allow-Origin": "*",
  "Access-Control-Allow-Methods": "GET, POST, PUT, DELETE, OPTIONS",
  "Access-Control-Allow-Headers": "Content-Type, Authorization, X-Client-Info, Apikey",
};

interface RecipeRequest {
  ingredients?: string[];
  dietaryPreferences?: string[];
  cuisineType?: string;
  servings?: number;
  difficulty?: string;
  maxPrepTime?: number;
}

interface RecipeResponse {
  title: string;
  description: string;
  instructions: string;
  ingredients: Array<{
    name: string;
    quantity: number;
    unit: string;
  }>;
  prepTime: number;
  cookTime: number;
  servings: number;
  nutrition: {
    calories: number;
    protein: number;
    carbs: number;
    fat: number;
  };
  cuisineType: string;
  difficultyLevel: string;
  tags: string[];
}

async function generateRecipeWithAI(
  request: RecipeRequest
): Promise<RecipeResponse> {
  const openAIKey = Deno.env.get("OPENAI_API_KEY");
  
  if (!openAIKey) {
    return generateFallbackRecipe(request);
  }

  try {
    const prompt = buildPrompt(request);
    
    const response = await fetch("https://api.openai.com/v1/chat/completions", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "Authorization": `Bearer ${openAIKey}`,
      },
      body: JSON.stringify({
        model: "gpt-4",
        messages: [
          {
            role: "system",
            content: "You are a professional chef and nutritionist. Generate detailed, practical recipes with accurate nutritional information. Always respond with valid JSON only."
          },
          {
            role: "user",
            content: prompt
          }
        ],
        temperature: 0.8,
      }),
    });

    if (!response.ok) {
      console.error("OpenAI API error:", await response.text());
      return generateFallbackRecipe(request);
    }

    const data = await response.json();
    const content = data.choices[0].message.content;
    
    const jsonMatch = content.match(/```json\n?([\s\S]*?)```/) || content.match(/({[\s\S]*})/);
    const jsonStr = jsonMatch ? jsonMatch[1] : content;
    
    return JSON.parse(jsonStr.trim());
  } catch (error) {
    console.error("Error generating recipe with AI:", error);
    return generateFallbackRecipe(request);
  }
}

function buildPrompt(request: RecipeRequest): string {
  const parts = [
    "Generate a detailed recipe with the following requirements:",
  ];

  if (request.ingredients && request.ingredients.length > 0) {
    parts.push(`- Must include these ingredients: ${request.ingredients.join(", ")}`);
  }

  if (request.dietaryPreferences && request.dietaryPreferences.length > 0) {
    parts.push(`- Dietary preferences: ${request.dietaryPreferences.join(", ")}`);
  }

  if (request.cuisineType) {
    parts.push(`- Cuisine type: ${request.cuisineType}`);
  }

  if (request.servings) {
    parts.push(`- Servings: ${request.servings}`);
  }

  if (request.difficulty) {
    parts.push(`- Difficulty level: ${request.difficulty}`);
  }

  if (request.maxPrepTime) {
    parts.push(`- Maximum preparation time: ${request.maxPrepTime} minutes`);
  }

  parts.push(`

Respond with a JSON object in this exact format:
{
  "title": "Recipe Name",
  "description": "Brief description of the dish",
  "instructions": "Step 1: ...\\nStep 2: ...\\nStep 3: ...",
  "ingredients": [
    {"name": "ingredient name", "quantity": 200, "unit": "g"},
    {"name": "ingredient name", "quantity": 2, "unit": "pieces"}
  ],
  "prepTime": 15,
  "cookTime": 30,
  "servings": 4,
  "nutrition": {
    "calories": 350,
    "protein": 25,
    "carbs": 40,
    "fat": 12
  },
  "cuisineType": "italian",
  "difficultyLevel": "medium",
  "tags": ["healthy", "quick", "dinner"]
}`);

  return parts.join("\n");
}

function generateFallbackRecipe(request: RecipeRequest): RecipeResponse {
  const cuisineType = request.cuisineType || "american";
  const servings = request.servings || 4;
  const difficulty = request.difficulty || "medium";
  
  const recipes = [
    {
      title: "Classic Grilled Chicken with Roasted Vegetables",
      description: "A healthy and delicious meal featuring tender grilled chicken breast with colorful roasted vegetables.",
      instructions: "Step 1: Preheat oven to 425°F (220°C).\nStep 2: Season chicken breasts with salt, pepper, and herbs.\nStep 3: Chop vegetables (bell peppers, zucchini, carrots) into bite-sized pieces.\nStep 4: Toss vegetables with olive oil, salt, and pepper.\nStep 5: Grill chicken for 6-7 minutes per side until cooked through.\nStep 6: Roast vegetables for 25-30 minutes until tender and caramelized.\nStep 7: Serve chicken with roasted vegetables.",
      ingredients: [
        { name: "chicken breast", quantity: 600, unit: "g" },
        { name: "bell peppers", quantity: 2, unit: "pieces" },
        { name: "zucchini", quantity: 2, unit: "pieces" },
        { name: "carrots", quantity: 3, unit: "pieces" },
        { name: "olive oil", quantity: 3, unit: "tbsp" },
        { name: "salt", quantity: 1, unit: "tsp" },
        { name: "black pepper", quantity: 0.5, unit: "tsp" },
      ],
      prepTime: 15,
      cookTime: 30,
      servings: servings,
      nutrition: {
        calories: 320,
        protein: 35,
        carbs: 18,
        fat: 12,
      },
      cuisineType: cuisineType,
      difficultyLevel: difficulty,
      tags: ["healthy", "high-protein", "gluten-free"],
    },
    {
      title: "Mediterranean Quinoa Bowl",
      description: "A nutritious vegetarian bowl packed with quinoa, fresh vegetables, and a tangy lemon dressing.",
      instructions: "Step 1: Cook quinoa according to package instructions.\nStep 2: Dice cucumber, tomatoes, and bell peppers.\nStep 3: Chop fresh parsley and mint.\nStep 4: Prepare dressing by whisking together lemon juice, olive oil, garlic, salt, and pepper.\nStep 5: Combine cooked quinoa with vegetables and chickpeas.\nStep 6: Toss with dressing and top with crumbled feta cheese.\nStep 7: Garnish with fresh herbs.",
      ingredients: [
        { name: "quinoa", quantity: 200, unit: "g" },
        { name: "cucumber", quantity: 1, unit: "piece" },
        { name: "tomatoes", quantity: 2, unit: "pieces" },
        { name: "chickpeas", quantity: 400, unit: "g" },
        { name: "olive oil", quantity: 3, unit: "tbsp" },
        { name: "lemons", quantity: 2, unit: "pieces" },
        { name: "garlic", quantity: 2, unit: "cloves" },
        { name: "parsley", quantity: 30, unit: "g" },
      ],
      prepTime: 20,
      cookTime: 15,
      servings: servings,
      nutrition: {
        calories: 380,
        protein: 14,
        carbs: 52,
        fat: 14,
      },
      cuisineType: cuisineType,
      difficultyLevel: difficulty,
      tags: ["vegetarian", "healthy", "mediterranean"],
    },
  ];

  return recipes[Math.floor(Math.random() * recipes.length)];
}

Deno.serve(async (req: Request) => {
  if (req.method === "OPTIONS") {
    return new Response(null, {
      status: 200,
      headers: corsHeaders,
    });
  }

  try {
    const requestData: RecipeRequest = await req.json();
    
    const recipe = await generateRecipeWithAI(requestData);

    return new Response(
      JSON.stringify({ success: true, recipe }),
      {
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  } catch (error) {
    console.error("Error in generate-recipe function:", error);
    
    return new Response(
      JSON.stringify({
        success: false,
        error: error instanceof Error ? error.message : "Unknown error",
      }),
      {
        status: 500,
        headers: {
          ...corsHeaders,
          "Content-Type": "application/json",
        },
      }
    );
  }
});