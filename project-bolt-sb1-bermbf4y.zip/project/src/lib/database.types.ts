export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      profiles: {
        Row: {
          id: string
          email: string
          full_name: string | null
          avatar_url: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id: string
          email: string
          full_name?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          email?: string
          full_name?: string | null
          avatar_url?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      dietary_preferences: {
        Row: {
          id: string
          user_id: string
          preference_type: string
          is_active: boolean
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          preference_type: string
          is_active?: boolean
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          preference_type?: string
          is_active?: boolean
          created_at?: string
        }
      }
      nutrition_goals: {
        Row: {
          id: string
          user_id: string
          daily_calories: number
          daily_protein_g: number
          daily_carbs_g: number
          daily_fat_g: number
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          daily_calories?: number
          daily_protein_g?: number
          daily_carbs_g?: number
          daily_fat_g?: number
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          daily_calories?: number
          daily_protein_g?: number
          daily_carbs_g?: number
          daily_fat_g?: number
          created_at?: string
          updated_at?: string
        }
      }
      ingredients: {
        Row: {
          id: string
          name: string
          category: string
          calories_per_100g: number
          protein_per_100g: number
          carbs_per_100g: number
          fat_per_100g: number
          created_at: string
        }
        Insert: {
          id?: string
          name: string
          category?: string
          calories_per_100g?: number
          protein_per_100g?: number
          carbs_per_100g?: number
          fat_per_100g?: number
          created_at?: string
        }
        Update: {
          id?: string
          name?: string
          category?: string
          calories_per_100g?: number
          protein_per_100g?: number
          carbs_per_100g?: number
          fat_per_100g?: number
          created_at?: string
        }
      }
      recipes: {
        Row: {
          id: string
          user_id: string
          title: string
          description: string
          instructions: string
          prep_time_minutes: number
          cook_time_minutes: number
          servings: number
          calories_per_serving: number
          protein_g: number
          carbs_g: number
          fat_g: number
          image_url: string | null
          is_ai_generated: boolean
          cuisine_type: string
          difficulty_level: string
          tags: string[]
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          title: string
          description?: string
          instructions?: string
          prep_time_minutes?: number
          cook_time_minutes?: number
          servings?: number
          calories_per_serving?: number
          protein_g?: number
          carbs_g?: number
          fat_g?: number
          image_url?: string | null
          is_ai_generated?: boolean
          cuisine_type?: string
          difficulty_level?: string
          tags?: string[]
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          title?: string
          description?: string
          instructions?: string
          prep_time_minutes?: number
          cook_time_minutes?: number
          servings?: number
          calories_per_serving?: number
          protein_g?: number
          carbs_g?: number
          fat_g?: number
          image_url?: string | null
          is_ai_generated?: boolean
          cuisine_type?: string
          difficulty_level?: string
          tags?: string[]
          created_at?: string
          updated_at?: string
        }
      }
      recipe_ingredients: {
        Row: {
          id: string
          recipe_id: string
          ingredient_id: string
          quantity: number
          unit: string
          notes: string
        }
        Insert: {
          id?: string
          recipe_id: string
          ingredient_id: string
          quantity: number
          unit: string
          notes?: string
        }
        Update: {
          id?: string
          recipe_id?: string
          ingredient_id?: string
          quantity?: number
          unit?: string
          notes?: string
        }
      }
      user_inventory: {
        Row: {
          id: string
          user_id: string
          ingredient_id: string
          quantity: number
          unit: string
          expiry_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          user_id: string
          ingredient_id: string
          quantity: number
          unit: string
          expiry_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          ingredient_id?: string
          quantity?: number
          unit?: string
          expiry_date?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      meal_plans: {
        Row: {
          id: string
          user_id: string
          date: string
          meal_type: string
          recipe_id: string
          servings: number
          notes: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          date: string
          meal_type: string
          recipe_id: string
          servings?: number
          notes?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          date?: string
          meal_type?: string
          recipe_id?: string
          servings?: number
          notes?: string
          created_at?: string
        }
      }
      shopping_lists: {
        Row: {
          id: string
          user_id: string
          ingredient_id: string
          quantity: number
          unit: string
          is_purchased: boolean
          notes: string
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          ingredient_id: string
          quantity: number
          unit: string
          is_purchased?: boolean
          notes?: string
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          ingredient_id?: string
          quantity?: number
          unit?: string
          is_purchased?: boolean
          notes?: string
          created_at?: string
        }
      }
      recipe_ratings: {
        Row: {
          id: string
          recipe_id: string
          user_id: string
          rating: number
          review: string
          created_at: string
        }
        Insert: {
          id?: string
          recipe_id: string
          user_id: string
          rating: number
          review?: string
          created_at?: string
        }
        Update: {
          id?: string
          recipe_id?: string
          user_id?: string
          rating?: number
          review?: string
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      [_ in never]: never
    }
    Enums: {
      [_ in never]: never
    }
  }
}
