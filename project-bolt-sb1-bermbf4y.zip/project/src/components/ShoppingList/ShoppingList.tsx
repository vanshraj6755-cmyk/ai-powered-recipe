import { useEffect, useState } from 'react';
import { ShoppingCart, Plus, Trash2, Check } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

interface ShoppingItem {
  id: string;
  ingredient_id: string;
  quantity: number;
  unit: string;
  is_purchased: boolean;
  notes: string;
  ingredients?: {
    name: string;
    category: string;
  };
}

export function ShoppingList() {
  const { user } = useAuth();
  const [items, setItems] = useState<ShoppingItem[]>([]);
  const [ingredients, setIngredients] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedIngredientId, setSelectedIngredientId] = useState('');
  const [quantity, setQuantity] = useState(1);
  const [unit, setUnit] = useState('pieces');

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    try {
      const { data: itemsData, error: itemsError } = await supabase
        .from('shopping_lists')
        .select(`
          *,
          ingredients (name, category)
        `)
        .eq('user_id', user.id)
        .order('is_purchased', { ascending: true })
        .order('created_at', { ascending: false });

      const { data: ingredientsData } = await supabase
        .from('ingredients')
        .select('*')
        .order('name');

      if (itemsError) throw itemsError;

      setItems(itemsData || []);
      setIngredients(ingredientsData || []);
    } catch (error) {
      console.error('Error loading shopping list:', error);
    } finally {
      setLoading(false);
    }
  };

  const addItem = async () => {
    if (!user || !selectedIngredientId) return;

    try {
      const { error } = await supabase.from('shopping_lists').insert({
        user_id: user.id,
        ingredient_id: selectedIngredientId,
        quantity,
        unit,
        is_purchased: false,
      });

      if (error) throw error;

      setShowAddModal(false);
      setSelectedIngredientId('');
      setQuantity(1);
      setUnit('pieces');
      loadData();
    } catch (err) {
      alert('Failed to add item');
    }
  };

  const togglePurchased = async (itemId: string, currentStatus: boolean) => {
    try {
      const { error } = await supabase
        .from('shopping_lists')
        .update({ is_purchased: !currentStatus })
        .eq('id', itemId);

      if (error) throw error;
      loadData();
    } catch (err) {
      alert('Failed to update item');
    }
  };

  const deleteItem = async (itemId: string) => {
    try {
      const { error } = await supabase.from('shopping_lists').delete().eq('id', itemId);

      if (error) throw error;
      loadData();
    } catch (err) {
      alert('Failed to delete item');
    }
  };

  const clearPurchased = async () => {
    try {
      const { error } = await supabase
        .from('shopping_lists')
        .delete()
        .eq('user_id', user!.id)
        .eq('is_purchased', true);

      if (error) throw error;
      loadData();
    } catch (err) {
      alert('Failed to clear purchased items');
    }
  };

  const pendingItems = items.filter((item) => !item.is_purchased);
  const purchasedItems = items.filter((item) => item.is_purchased);

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-blue-500 to-indigo-500 p-3 rounded-lg">
              <ShoppingCart className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Shopping List</h2>
              <p className="text-sm text-gray-600">
                {pendingItems.length} items to buy
              </p>
            </div>
          </div>

          <button
            onClick={() => setShowAddModal(true)}
            className="flex items-center gap-2 bg-blue-500 text-white px-4 py-2 rounded-lg hover:bg-blue-600 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Add Item
          </button>
        </div>

        <div className="space-y-4">
          {pendingItems.length === 0 && purchasedItems.length === 0 ? (
            <div className="text-center py-12">
              <ShoppingCart className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">No items in your list</h3>
              <p className="text-gray-600 mb-4">Add ingredients you need to buy</p>
              <button
                onClick={() => setShowAddModal(true)}
                className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
              >
                Add First Item
              </button>
            </div>
          ) : (
            <>
              {pendingItems.length > 0 && (
                <div>
                  <h3 className="font-semibold text-gray-900 mb-3">To Buy</h3>
                  <div className="space-y-2">
                    {pendingItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 p-3 bg-gray-50 rounded-lg hover:bg-gray-100 transition-colors"
                      >
                        <button
                          onClick={() => togglePurchased(item.id, item.is_purchased)}
                          className="flex-shrink-0 w-5 h-5 border-2 border-gray-400 rounded hover:border-green-500 transition-colors"
                        />
                        <div className="flex-1">
                          <p className="font-medium text-gray-900">{item.ingredients?.name}</p>
                          <p className="text-sm text-gray-600">
                            {item.quantity} {item.unit}
                          </p>
                        </div>
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="text-red-500 hover:text-red-700 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}

              {purchasedItems.length > 0 && (
                <div>
                  <div className="flex items-center justify-between mb-3">
                    <h3 className="font-semibold text-gray-900">Purchased</h3>
                    <button
                      onClick={clearPurchased}
                      className="text-sm text-gray-600 hover:text-gray-900 transition-colors"
                    >
                      Clear All
                    </button>
                  </div>
                  <div className="space-y-2">
                    {purchasedItems.map((item) => (
                      <div
                        key={item.id}
                        className="flex items-center gap-3 p-3 bg-green-50 rounded-lg"
                      >
                        <button
                          onClick={() => togglePurchased(item.id, item.is_purchased)}
                          className="flex-shrink-0 w-5 h-5 bg-green-500 border-2 border-green-500 rounded flex items-center justify-center"
                        >
                          <Check className="w-4 h-4 text-white" />
                        </button>
                        <div className="flex-1">
                          <p className="font-medium text-gray-600 line-through">
                            {item.ingredients?.name}
                          </p>
                          <p className="text-sm text-gray-500">
                            {item.quantity} {item.unit}
                          </p>
                        </div>
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="text-red-500 hover:text-red-700 transition-colors"
                        >
                          <Trash2 className="w-5 h-5" />
                        </button>
                      </div>
                    ))}
                  </div>
                </div>
              )}
            </>
          )}
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Add Shopping Item</h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Ingredient</label>
                <select
                  value={selectedIngredientId}
                  onChange={(e) => setSelectedIngredientId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                >
                  <option value="">Select an ingredient</option>
                  {ingredients.map((ing) => (
                    <option key={ing.id} value={ing.id}>
                      {ing.name}
                    </option>
                  ))}
                </select>
              </div>

              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Quantity</label>
                  <input
                    type="number"
                    value={quantity}
                    onChange={(e) => setQuantity(parseFloat(e.target.value) || 1)}
                    min="0.1"
                    step="0.1"
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  />
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-1">Unit</label>
                  <select
                    value={unit}
                    onChange={(e) => setUnit(e.target.value)}
                    className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-blue-500 focus:border-transparent"
                  >
                    <option value="pieces">pieces</option>
                    <option value="g">grams</option>
                    <option value="kg">kilograms</option>
                    <option value="ml">milliliters</option>
                    <option value="l">liters</option>
                    <option value="cups">cups</option>
                    <option value="tbsp">tablespoons</option>
                    <option value="tsp">teaspoons</option>
                  </select>
                </div>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={addItem}
                  disabled={!selectedIngredientId}
                  className="flex-1 bg-blue-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Add Item
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
