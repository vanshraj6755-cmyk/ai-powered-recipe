import { useEffect, useState } from 'react';
import { BarChart3, TrendingUp, Target } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

interface NutritionGoals {
  daily_calories: number;
  daily_protein_g: number;
  daily_carbs_g: number;
  daily_fat_g: number;
}

interface DailyNutrition {
  calories: number;
  protein: number;
  carbs: number;
  fat: number;
}

export function NutritionTracker() {
  const { user } = useAuth();
  const [goals, setGoals] = useState<NutritionGoals>({
    daily_calories: 2000,
    daily_protein_g: 50,
    daily_carbs_g: 250,
    daily_fat_g: 70,
  });
  const [todayNutrition, setTodayNutrition] = useState<DailyNutrition>({
    calories: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
  });
  const [loading, setLoading] = useState(true);
  const [editingGoals, setEditingGoals] = useState(false);

  useEffect(() => {
    loadData();
  }, [user]);

  const loadData = async () => {
    if (!user) return;

    try {
      const { data: goalsData } = await supabase
        .from('nutrition_goals')
        .select('*')
        .eq('user_id', user.id)
        .maybeSingle();

      if (goalsData) {
        setGoals(goalsData);
      }

      const today = new Date().toISOString().split('T')[0];
      const { data: mealPlans } = await supabase
        .from('meal_plans')
        .select(`
          servings,
          recipes (
            calories_per_serving,
            protein_g,
            carbs_g,
            fat_g
          )
        `)
        .eq('user_id', user.id)
        .eq('date', today);

      if (mealPlans) {
        const nutrition = mealPlans.reduce(
          (acc, meal) => {
            const recipe = meal.recipes as any;
            if (recipe) {
              acc.calories += recipe.calories_per_serving * meal.servings;
              acc.protein += recipe.protein_g * meal.servings;
              acc.carbs += recipe.carbs_g * meal.servings;
              acc.fat += recipe.fat_g * meal.servings;
            }
            return acc;
          },
          { calories: 0, protein: 0, carbs: 0, fat: 0 }
        );

        setTodayNutrition(nutrition);
      }
    } catch (error) {
      console.error('Error loading nutrition data:', error);
    } finally {
      setLoading(false);
    }
  };

  const saveGoals = async () => {
    if (!user) return;

    try {
      const { data: existing } = await supabase
        .from('nutrition_goals')
        .select('id')
        .eq('user_id', user.id)
        .maybeSingle();

      if (existing) {
        await supabase
          .from('nutrition_goals')
          .update({
            daily_calories: goals.daily_calories,
            daily_protein_g: goals.daily_protein_g,
            daily_carbs_g: goals.daily_carbs_g,
            daily_fat_g: goals.daily_fat_g,
            updated_at: new Date().toISOString(),
          })
          .eq('user_id', user.id);
      } else {
        await supabase.from('nutrition_goals').insert({
          user_id: user.id,
          ...goals,
        });
      }

      setEditingGoals(false);
      alert('Goals saved successfully!');
    } catch (err) {
      alert('Failed to save goals');
    }
  };

  const getProgressPercentage = (current: number, goal: number) => {
    return Math.min((current / goal) * 100, 100);
  };

  const getProgressColor = (percentage: number) => {
    if (percentage >= 90) return 'bg-green-500';
    if (percentage >= 70) return 'bg-yellow-500';
    return 'bg-blue-500';
  };

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  const nutrients = [
    {
      name: 'Calories',
      current: Math.round(todayNutrition.calories),
      goal: goals.daily_calories,
      unit: 'kcal',
      icon: TrendingUp,
    },
    {
      name: 'Protein',
      current: Math.round(todayNutrition.protein),
      goal: goals.daily_protein_g,
      unit: 'g',
      icon: Target,
    },
    {
      name: 'Carbs',
      current: Math.round(todayNutrition.carbs),
      goal: goals.daily_carbs_g,
      unit: 'g',
      icon: Target,
    },
    {
      name: 'Fat',
      current: Math.round(todayNutrition.fat),
      goal: goals.daily_fat_g,
      unit: 'g',
      icon: Target,
    },
  ];

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-green-500 to-teal-500 p-3 rounded-lg">
              <BarChart3 className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Nutrition Tracker</h2>
              <p className="text-sm text-gray-600">Track your daily nutrition goals</p>
            </div>
          </div>

          <button
            onClick={() => setEditingGoals(!editingGoals)}
            className="px-4 py-2 bg-gray-100 text-gray-700 rounded-lg hover:bg-gray-200 transition-colors"
          >
            {editingGoals ? 'Cancel' : 'Edit Goals'}
          </button>
        </div>

        {editingGoals ? (
          <div className="space-y-4">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Daily Calories (kcal)
                </label>
                <input
                  type="number"
                  value={goals.daily_calories}
                  onChange={(e) =>
                    setGoals({ ...goals, daily_calories: parseInt(e.target.value) || 0 })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Daily Protein (g)
                </label>
                <input
                  type="number"
                  value={goals.daily_protein_g}
                  onChange={(e) =>
                    setGoals({ ...goals, daily_protein_g: parseInt(e.target.value) || 0 })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Daily Carbs (g)
                </label>
                <input
                  type="number"
                  value={goals.daily_carbs_g}
                  onChange={(e) =>
                    setGoals({ ...goals, daily_carbs_g: parseInt(e.target.value) || 0 })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>

              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">
                  Daily Fat (g)
                </label>
                <input
                  type="number"
                  value={goals.daily_fat_g}
                  onChange={(e) =>
                    setGoals({ ...goals, daily_fat_g: parseInt(e.target.value) || 0 })
                  }
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                />
              </div>
            </div>

            <button
              onClick={saveGoals}
              className="w-full bg-green-500 text-white font-semibold py-3 px-4 rounded-lg hover:bg-green-600 transition-colors"
            >
              Save Goals
            </button>
          </div>
        ) : (
          <div className="space-y-6">
            <div className="bg-gradient-to-r from-green-50 to-teal-50 rounded-lg p-4">
              <p className="text-sm text-gray-600 mb-1">Today's Progress</p>
              <p className="text-3xl font-bold text-gray-900">
                {Math.round(todayNutrition.calories)} / {goals.daily_calories} kcal
              </p>
              <p className="text-sm text-gray-600 mt-1">
                {Math.round(getProgressPercentage(todayNutrition.calories, goals.daily_calories))}%
                of daily goal
              </p>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
              {nutrients.map((nutrient) => {
                const Icon = nutrient.icon;
                const percentage = getProgressPercentage(nutrient.current, nutrient.goal);
                const color = getProgressColor(percentage);

                return (
                  <div key={nutrient.name} className="bg-gray-50 rounded-lg p-4">
                    <div className="flex items-center gap-2 mb-3">
                      <Icon className="w-5 h-5 text-gray-600" />
                      <h4 className="font-semibold text-gray-900">{nutrient.name}</h4>
                    </div>

                    <div className="space-y-2">
                      <div className="flex justify-between text-sm">
                        <span className="text-gray-600">
                          {nutrient.current} / {nutrient.goal} {nutrient.unit}
                        </span>
                        <span className="font-medium text-gray-900">
                          {Math.round(percentage)}%
                        </span>
                      </div>

                      <div className="w-full bg-gray-200 rounded-full h-2">
                        <div
                          className={`${color} h-2 rounded-full transition-all duration-500`}
                          style={{ width: `${percentage}%` }}
                        ></div>
                      </div>
                    </div>
                  </div>
                );
              })}
            </div>

            <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
              <h4 className="font-semibold text-blue-900 mb-2">Nutrition Tips</h4>
              <ul className="space-y-1 text-sm text-blue-800">
                <li>• Add meals to your meal plan to track nutrition automatically</li>
                <li>• Aim to meet 90-100% of your daily goals</li>
                <li>• Balance your macronutrients throughout the day</li>
                <li>• Adjust goals based on your fitness objectives</li>
              </ul>
            </div>
          </div>
        )}
      </div>
    </div>
  );
}
