import { useEffect, useState } from 'react';
import { Calendar, BookOpen, ShoppingCart, TrendingUp, Sparkles, Camera } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

interface Stats {
  recipesCount: number;
  mealPlansCount: number;
  shoppingListCount: number;
}

interface DashboardProps {
  onNavigate: (tab: string) => void;
}

export function Dashboard({ onNavigate }: DashboardProps) {
  const { user } = useAuth();
  const [stats, setStats] = useState<Stats>({ recipesCount: 0, mealPlansCount: 0, shoppingListCount: 0 });
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    loadStats();
  }, [user]);

  const loadStats = async () => {
    if (!user) return;

    try {
      const [recipesResult, mealPlansResult, shoppingResult] = await Promise.all([
        supabase.from('recipes').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
        supabase.from('meal_plans').select('id', { count: 'exact', head: true }).eq('user_id', user.id),
        supabase.from('shopping_lists').select('id', { count: 'exact', head: true }).eq('user_id', user.id).eq('is_purchased', false),
      ]);

      setStats({
        recipesCount: recipesResult.count || 0,
        mealPlansCount: mealPlansResult.count || 0,
        shoppingListCount: shoppingResult.count || 0,
      });
    } catch (error) {
      console.error('Error loading stats:', error);
    } finally {
      setLoading(false);
    }
  };

  const quickActions = [
    {
      title: 'Generate Recipe',
      description: 'Create a custom recipe with AI',
      icon: Sparkles,
      color: 'from-purple-500 to-pink-500',
      action: () => onNavigate('generate'),
    },
    {
      title: 'Scan Ingredients',
      description: 'Identify ingredients from photos',
      icon: Camera,
      color: 'from-blue-500 to-cyan-500',
      action: () => onNavigate('recognize'),
    },
    {
      title: 'Browse Recipes',
      description: 'Explore recipe collection',
      icon: BookOpen,
      color: 'from-green-500 to-emerald-500',
      action: () => onNavigate('recipes'),
    },
    {
      title: 'Plan Meals',
      description: 'Schedule your weekly meals',
      icon: Calendar,
      color: 'from-orange-500 to-red-500',
      action: () => onNavigate('meal-plan'),
    },
  ];

  const statCards = [
    { label: 'My Recipes', value: stats.recipesCount, icon: BookOpen, color: 'text-green-600', bg: 'bg-green-50' },
    { label: 'Meal Plans', value: stats.mealPlansCount, icon: Calendar, color: 'text-orange-600', bg: 'bg-orange-50' },
    { label: 'Shopping Items', value: stats.shoppingListCount, icon: ShoppingCart, color: 'text-blue-600', bg: 'bg-blue-50' },
  ];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-br from-green-500 to-emerald-600 rounded-2xl shadow-lg p-8 text-white">
        <div className="flex items-center gap-3 mb-4">
          <TrendingUp className="w-8 h-8" />
          <h2 className="text-3xl font-bold">Welcome Back!</h2>
        </div>
        <p className="text-green-50 text-lg">
          Discover new recipes, plan your meals, and achieve your nutrition goals with AI-powered assistance.
        </p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {statCards.map((stat) => {
          const Icon = stat.icon;
          return (
            <div key={stat.label} className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium text-gray-600">{stat.label}</p>
                  <p className="text-3xl font-bold text-gray-900 mt-1">{stat.value}</p>
                </div>
                <div className={`${stat.bg} p-3 rounded-lg`}>
                  <Icon className={`w-6 h-6 ${stat.color}`} />
                </div>
              </div>
            </div>
          );
        })}
      </div>

      <div>
        <h3 className="text-xl font-bold text-gray-900 mb-4">Quick Actions</h3>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          {quickActions.map((action) => {
            const Icon = action.icon;
            return (
              <button
                key={action.title}
                onClick={action.action}
                className="group bg-white rounded-xl shadow-sm border border-gray-200 p-6 hover:shadow-md transition-all text-left"
              >
                <div className="flex items-start gap-4">
                  <div className={`bg-gradient-to-br ${action.color} p-3 rounded-lg group-hover:scale-110 transition-transform`}>
                    <Icon className="w-6 h-6 text-white" />
                  </div>
                  <div className="flex-1">
                    <h4 className="font-semibold text-gray-900 mb-1">{action.title}</h4>
                    <p className="text-sm text-gray-600">{action.description}</p>
                  </div>
                </div>
              </button>
            );
          })}
        </div>
      </div>
    </div>
  );
}
