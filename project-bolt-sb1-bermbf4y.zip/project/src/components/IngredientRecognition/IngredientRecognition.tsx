import { useState, useRef } from 'react';
import { Camera, Upload, Loader2, Check } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

export function IngredientRecognition() {
  const { user } = useAuth();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const [selectedImage, setSelectedImage] = useState<string | null>(null);
  const [recognizing, setRecognizing] = useState(false);
  const [recognizedIngredients, setRecognizedIngredients] = useState<string[]>([]);
  const [confidence, setConfidence] = useState<number>(0);
  const [error, setError] = useState('');

  const handleFileSelect = (event: React.ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onload = (e) => {
        setSelectedImage(e.target?.result as string);
        setRecognizedIngredients([]);
        setConfidence(0);
      };
      reader.readAsDataURL(file);
    }
  };

  const recognizeIngredients = async () => {
    if (!selectedImage) return;

    setRecognizing(true);
    setError('');

    try {
      const response = await fetch(
        `${import.meta.env.VITE_SUPABASE_URL}/functions/v1/recognize-ingredients`,
        {
          method: 'POST',
          headers: {
            'Authorization': `Bearer ${import.meta.env.VITE_SUPABASE_ANON_KEY}`,
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ image: selectedImage }),
        }
      );

      const data = await response.json();

      if (!data.success) {
        throw new Error(data.error || 'Failed to recognize ingredients');
      }

      setRecognizedIngredients(data.ingredients);
      setConfidence(data.confidence);
    } catch (err) {
      setError(err instanceof Error ? err.message : 'Failed to recognize ingredients');
    } finally {
      setRecognizing(false);
    }
  };

  const addToInventory = async () => {
    if (!user || recognizedIngredients.length === 0) return;

    try {
      const { data: ingredientsData } = await supabase
        .from('ingredients')
        .select('*')
        .in('name', recognizedIngredients);

      if (ingredientsData) {
        const inventoryItems = ingredientsData.map((ing) => ({
          user_id: user.id,
          ingredient_id: ing.id,
          quantity: 1,
          unit: 'piece',
        }));

        const { error } = await supabase.from('user_inventory').insert(inventoryItems);

        if (error) throw error;

        alert('Ingredients added to your inventory!');
        setSelectedImage(null);
        setRecognizedIngredients([]);
      }
    } catch (err) {
      alert('Failed to add ingredients to inventory');
    }
  };

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center gap-3 mb-6">
          <div className="bg-gradient-to-br from-blue-500 to-cyan-500 p-3 rounded-lg">
            <Camera className="w-6 h-6 text-white" />
          </div>
          <div>
            <h2 className="text-2xl font-bold text-gray-900">Ingredient Recognition</h2>
            <p className="text-sm text-gray-600">Identify ingredients from photos using AI</p>
          </div>
        </div>

        {error && (
          <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg mb-4">
            {error}
          </div>
        )}

        <div className="space-y-6">
          {!selectedImage ? (
            <div className="border-2 border-dashed border-gray-300 rounded-lg p-12 text-center hover:border-blue-500 transition-colors">
              <Upload className="w-12 h-12 text-gray-400 mx-auto mb-4" />
              <h3 className="text-lg font-semibold text-gray-900 mb-2">Upload Ingredient Photo</h3>
              <p className="text-gray-600 mb-4">Take or upload a photo of your ingredients</p>
              <button
                onClick={() => fileInputRef.current?.click()}
                className="bg-blue-500 text-white px-6 py-2 rounded-lg hover:bg-blue-600 transition-colors"
              >
                Choose Image
              </button>
              <input
                ref={fileInputRef}
                type="file"
                accept="image/*"
                onChange={handleFileSelect}
                className="hidden"
              />
            </div>
          ) : (
            <div className="space-y-4">
              <div className="relative">
                <img
                  src={selectedImage}
                  alt="Selected ingredients"
                  className="w-full h-96 object-contain rounded-lg bg-gray-100"
                />
              </div>

              {recognizedIngredients.length === 0 ? (
                <button
                  onClick={recognizeIngredients}
                  disabled={recognizing}
                  className="w-full bg-blue-500 text-white font-semibold py-3 px-4 rounded-lg hover:bg-blue-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
                >
                  {recognizing ? (
                    <>
                      <Loader2 className="w-5 h-5 animate-spin" />
                      Recognizing...
                    </>
                  ) : (
                    <>
                      <Camera className="w-5 h-5" />
                      Recognize Ingredients
                    </>
                  )}
                </button>
              ) : (
                <div className="bg-green-50 border border-green-200 rounded-lg p-4">
                  <div className="flex items-center gap-2 mb-3">
                    <Check className="w-5 h-5 text-green-600" />
                    <h4 className="font-semibold text-green-900">
                      Recognized Ingredients (Confidence: {Math.round(confidence * 100)}%)
                    </h4>
                  </div>
                  <div className="flex flex-wrap gap-2 mb-4">
                    {recognizedIngredients.map((ingredient) => (
                      <span
                        key={ingredient}
                        className="px-3 py-1 bg-white border border-green-300 text-green-800 rounded-full text-sm font-medium"
                      >
                        {ingredient}
                      </span>
                    ))}
                  </div>
                  <div className="flex gap-2">
                    <button
                      onClick={addToInventory}
                      className="flex-1 bg-green-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors"
                    >
                      Add to Inventory
                    </button>
                    <button
                      onClick={() => {
                        setSelectedImage(null);
                        setRecognizedIngredients([]);
                      }}
                      className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                    >
                      Try Another
                    </button>
                  </div>
                </div>
              )}

              {recognizedIngredients.length === 0 && !recognizing && (
                <button
                  onClick={() => setSelectedImage(null)}
                  className="w-full px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Choose Different Image
                </button>
              )}
            </div>
          )}
        </div>
      </div>

      <div className="bg-blue-50 border border-blue-200 rounded-lg p-4">
        <h4 className="font-semibold text-blue-900 mb-2">Tips for Best Results</h4>
        <ul className="space-y-1 text-sm text-blue-800">
          <li>• Use good lighting and clear images</li>
          <li>• Separate ingredients visibly</li>
          <li>• Include multiple angles if needed</li>
          <li>• Avoid cluttered backgrounds</li>
        </ul>
      </div>
    </div>
  );
}
