import { useEffect, useState } from 'react';
import { Calendar, Plus, ChevronLeft, ChevronRight } from 'lucide-react';
import { useAuth } from '../../contexts/AuthContext';
import { supabase } from '../../lib/supabase';

interface MealPlan {
  id: string;
  date: string;
  meal_type: string;
  recipe_id: string;
  servings: number;
  recipe?: {
    title: string;
    calories_per_serving: number;
  };
}

export function MealPlanner() {
  const { user } = useAuth();
  const [currentDate, setCurrentDate] = useState(new Date());
  const [mealPlans, setMealPlans] = useState<MealPlan[]>([]);
  const [recipes, setRecipes] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [showAddModal, setShowAddModal] = useState(false);
  const [selectedDate, setSelectedDate] = useState('');
  const [selectedMealType, setSelectedMealType] = useState('breakfast');
  const [selectedRecipeId, setSelectedRecipeId] = useState('');

  useEffect(() => {
    loadData();
  }, [user, currentDate]);

  const loadData = async () => {
    if (!user) return;

    try {
      const startDate = new Date(currentDate);
      startDate.setDate(startDate.getDate() - startDate.getDay());
      const endDate = new Date(startDate);
      endDate.setDate(endDate.getDate() + 7);

      const { data: mealData, error: mealError } = await supabase
        .from('meal_plans')
        .select(`
          *,
          recipes (title, calories_per_serving)
        `)
        .eq('user_id', user.id)
        .gte('date', startDate.toISOString().split('T')[0])
        .lte('date', endDate.toISOString().split('T')[0]);

      if (mealError) throw mealError;

      const { data: recipeData } = await supabase.from('recipes').select('*').limit(50);

      setMealPlans(mealData || []);
      setRecipes(recipeData || []);
    } catch (error) {
      console.error('Error loading meal plans:', error);
    } finally {
      setLoading(false);
    }
  };

  const addMealPlan = async () => {
    if (!user || !selectedRecipeId || !selectedDate) return;

    try {
      const { error } = await supabase.from('meal_plans').insert({
        user_id: user.id,
        date: selectedDate,
        meal_type: selectedMealType,
        recipe_id: selectedRecipeId,
        servings: 1,
      });

      if (error) throw error;

      setShowAddModal(false);
      setSelectedRecipeId('');
      loadData();
    } catch (err) {
      alert('Failed to add meal plan');
    }
  };

  const getWeekDays = () => {
    const start = new Date(currentDate);
    start.setDate(start.getDate() - start.getDay());
    return Array.from({ length: 7 }, (_, i) => {
      const day = new Date(start);
      day.setDate(day.getDate() + i);
      return day;
    });
  };

  const getMealForDay = (date: Date, mealType: string) => {
    const dateStr = date.toISOString().split('T')[0];
    return mealPlans.find((m) => m.date === dateStr && m.meal_type === mealType);
  };

  const weekDays = getWeekDays();
  const mealTypes = ['breakfast', 'lunch', 'dinner', 'snack'];

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-green-500"></div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl shadow-sm border border-gray-200 p-6">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-3">
            <div className="bg-gradient-to-br from-orange-500 to-red-500 p-3 rounded-lg">
              <Calendar className="w-6 h-6 text-white" />
            </div>
            <div>
              <h2 className="text-2xl font-bold text-gray-900">Meal Planner</h2>
              <p className="text-sm text-gray-600">Plan your weekly meals</p>
            </div>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => {
                const prev = new Date(currentDate);
                prev.setDate(prev.getDate() - 7);
                setCurrentDate(prev);
              }}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronLeft className="w-5 h-5" />
            </button>
            <button
              onClick={() => setCurrentDate(new Date())}
              className="px-4 py-2 text-sm font-medium text-gray-700 hover:bg-gray-100 rounded-lg transition-colors"
            >
              Today
            </button>
            <button
              onClick={() => {
                const next = new Date(currentDate);
                next.setDate(next.getDate() + 7);
                setCurrentDate(next);
              }}
              className="p-2 hover:bg-gray-100 rounded-lg transition-colors"
            >
              <ChevronRight className="w-5 h-5" />
            </button>
          </div>
        </div>

        <div className="overflow-x-auto">
          <table className="w-full border-collapse">
            <thead>
              <tr>
                <th className="border border-gray-200 bg-gray-50 p-3 text-left text-sm font-semibold text-gray-700">
                  Meal
                </th>
                {weekDays.map((day) => (
                  <th
                    key={day.toISOString()}
                    className="border border-gray-200 bg-gray-50 p-3 text-center text-sm font-semibold text-gray-700 min-w-32"
                  >
                    <div>{day.toLocaleDateString('en-US', { weekday: 'short' })}</div>
                    <div className="text-xs font-normal text-gray-600">
                      {day.toLocaleDateString('en-US', { month: 'short', day: 'numeric' })}
                    </div>
                  </th>
                ))}
              </tr>
            </thead>
            <tbody>
              {mealTypes.map((mealType) => (
                <tr key={mealType}>
                  <td className="border border-gray-200 p-3 font-medium text-gray-900 capitalize bg-gray-50">
                    {mealType}
                  </td>
                  {weekDays.map((day) => {
                    const meal = getMealForDay(day, mealType);
                    const dateStr = day.toISOString().split('T')[0];
                    return (
                      <td key={day.toISOString()} className="border border-gray-200 p-2 align-top">
                        {meal ? (
                          <div className="bg-green-50 border border-green-200 rounded-lg p-2 text-xs">
                            <p className="font-medium text-green-900 line-clamp-2">
                              {meal.recipe?.title}
                            </p>
                            <p className="text-green-700 mt-1">
                              {meal.recipe?.calories_per_serving} cal
                            </p>
                          </div>
                        ) : (
                          <button
                            onClick={() => {
                              setSelectedDate(dateStr);
                              setSelectedMealType(mealType);
                              setShowAddModal(true);
                            }}
                            className="w-full h-full min-h-16 flex items-center justify-center text-gray-400 hover:bg-gray-50 rounded-lg transition-colors"
                          >
                            <Plus className="w-5 h-5" />
                          </button>
                        )}
                      </td>
                    );
                  })}
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {showAddModal && (
        <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
          <div className="bg-white rounded-xl shadow-xl max-w-md w-full p-6">
            <h3 className="text-xl font-bold text-gray-900 mb-4">Add Meal</h3>

            <div className="space-y-4">
              <div>
                <label className="block text-sm font-medium text-gray-700 mb-1">Recipe</label>
                <select
                  value={selectedRecipeId}
                  onChange={(e) => setSelectedRecipeId(e.target.value)}
                  className="w-full px-4 py-2 border border-gray-300 rounded-lg focus:ring-2 focus:ring-green-500 focus:border-transparent"
                >
                  <option value="">Select a recipe</option>
                  {recipes.map((recipe) => (
                    <option key={recipe.id} value={recipe.id}>
                      {recipe.title}
                    </option>
                  ))}
                </select>
              </div>

              <div className="flex gap-2">
                <button
                  onClick={addMealPlan}
                  disabled={!selectedRecipeId}
                  className="flex-1 bg-green-500 text-white font-semibold py-2 px-4 rounded-lg hover:bg-green-600 transition-colors disabled:opacity-50 disabled:cursor-not-allowed"
                >
                  Add Meal
                </button>
                <button
                  onClick={() => setShowAddModal(false)}
                  className="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition-colors"
                >
                  Cancel
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
