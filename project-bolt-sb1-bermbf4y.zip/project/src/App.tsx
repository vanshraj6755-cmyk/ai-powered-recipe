import { useState } from 'react';
import { AuthProvider, useAuth } from './contexts/AuthContext';
import { AuthForm } from './components/Auth/AuthForm';
import { MainLayout } from './components/Layout/MainLayout';
import { Dashboard } from './components/Dashboard/Dashboard';
import { RecipeList } from './components/Recipes/RecipeList';
import { RecipeGenerator } from './components/RecipeGenerator/RecipeGenerator';
import { IngredientRecognition } from './components/IngredientRecognition/IngredientRecognition';
import { MealPlanner } from './components/MealPlanner/MealPlanner';
import { ShoppingList } from './components/ShoppingList/ShoppingList';
import { NutritionTracker } from './components/NutritionTracker/NutritionTracker';

function AppContent() {
  const { user, loading } = useAuth();
  const [activeTab, setActiveTab] = useState('home');

  if (loading) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-green-50 to-blue-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-16 w-16 border-b-4 border-green-500 mx-auto mb-4"></div>
          <p className="text-gray-600 font-medium">Loading RecipeAI...</p>
        </div>
      </div>
    );
  }

  if (!user) {
    return <AuthForm />;
  }

  const renderContent = () => {
    switch (activeTab) {
      case 'home':
        return <Dashboard onNavigate={setActiveTab} />;
      case 'recipes':
        return <RecipeList />;
      case 'generate':
        return <RecipeGenerator />;
      case 'recognize':
        return <IngredientRecognition />;
      case 'meal-plan':
        return <MealPlanner />;
      case 'shopping':
        return <ShoppingList />;
      case 'nutrition':
        return <NutritionTracker />;
      default:
        return <Dashboard onNavigate={setActiveTab} />;
    }
  };

  return (
    <MainLayout activeTab={activeTab} onTabChange={setActiveTab}>
      {renderContent()}
    </MainLayout>
  );
}

function App() {
  return (
    <AuthProvider>
      <AppContent />
    </AuthProvider>
  );
}

export default App;
