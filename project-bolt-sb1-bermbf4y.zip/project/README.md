# RecipeAI - AI-Powered Recipe Generator & Meal Planner

A comprehensive full-stack web application that uses artificial intelligence to generate personalized recipes, identify ingredients from photos, and help users plan their meals while tracking nutrition goals.

## Features

### Core Features

- **AI Recipe Generation**: Generate custom recipes based on available ingredients, dietary preferences, cuisine type, and difficulty level
- **Ingredient Recognition**: Use computer vision to identify ingredients from photos
- **Recipe Discovery**: Browse and search through a collection of recipes with advanced filtering
- **Meal Planning**: Interactive weekly meal planner with drag-and-drop functionality
- **Shopping List**: Automated shopping list generation based on meal plans
- **Nutrition Tracking**: Track daily nutrition goals and monitor progress
- **User Authentication**: Secure authentication with email/password and Google OAuth

### Technical Highlights

- Real-time data synchronization with Supabase
- Responsive design that works on mobile, tablet, and desktop
- Row-level security (RLS) for data protection
- RESTful API design with Supabase Edge Functions
- TypeScript for type safety
- Modern React with hooks and context API

## Tech Stack

### Frontend
- **React 18** - UI library
- **TypeScript** - Type safety
- **Vite** - Build tool and dev server
- **Tailwind CSS** - Utility-first CSS framework
- **Lucide React** - Icon library

### Backend
- **Supabase** - Backend as a Service
  - PostgreSQL database
  - Authentication (email/password + OAuth)
  - Edge Functions (serverless functions)
  - Row Level Security (RLS)

### AI Integration
- **OpenAI GPT-4** - Recipe generation and adaptation
- **OpenAI GPT-4 Vision** - Ingredient recognition from images

## Project Structure

```
project/
├── src/
│   ├── components/
│   │   ├── Auth/              # Authentication components
│   │   ├── Dashboard/         # Dashboard and home page
│   │   ├── Layout/            # Main layout and navigation
│   │   ├── Recipes/           # Recipe browsing and filtering
│   │   ├── RecipeGenerator/   # AI recipe generation interface
│   │   ├── IngredientRecognition/  # Photo upload and recognition
│   │   ├── MealPlanner/       # Weekly meal planning calendar
│   │   ├── ShoppingList/      # Shopping list management
│   │   └── NutritionTracker/  # Nutrition goals and tracking
│   ├── contexts/
│   │   └── AuthContext.tsx    # Authentication state management
│   ├── lib/
│   │   ├── supabase.ts        # Supabase client configuration
│   │   └── database.types.ts  # TypeScript database types
│   ├── App.tsx                # Main application component
│   ├── main.tsx               # Application entry point
│   └── index.css              # Global styles
├── supabase/
│   └── functions/             # Edge Functions
│       ├── generate-recipe/   # Recipe generation function
│       └── recognize-ingredients/  # Ingredient recognition function
└── README.md
```

## Database Schema

### Tables

1. **profiles** - User profiles with personal information
2. **dietary_preferences** - User dietary restrictions and preferences
3. **nutrition_goals** - Daily nutrition targets for each user
4. **ingredients** - Master ingredient library with nutritional data
5. **recipes** - Recipe collection with instructions and metadata
6. **recipe_ingredients** - Junction table linking recipes to ingredients
7. **user_inventory** - User's available ingredients
8. **meal_plans** - Scheduled meals for each user
9. **shopping_lists** - User shopping lists with purchase status
10. **recipe_ratings** - User ratings and reviews for recipes

All tables are protected with Row Level Security (RLS) policies ensuring users can only access their own data.

## Setup Instructions

### Prerequisites

- Node.js 18+ installed
- npm or yarn package manager
- Supabase account (database is already provisioned)
- OpenAI API key (optional, for AI features)

### Installation

1. Clone the repository:
```bash
git clone <repository-url>
cd project
```

2. Install dependencies:
```bash
npm install
```

3. Environment variables are already configured in `.env`:
```
VITE_SUPABASE_URL=<your-supabase-url>
VITE_SUPABASE_ANON_KEY=<your-supabase-anon-key>
```

4. The database schema and seed data are already applied through migrations.

5. Start the development server:
```bash
npm run dev
```

The application will be available at `http://localhost:5173`

### Optional: OpenAI Integration

To enable AI-powered recipe generation and ingredient recognition:

1. Get an OpenAI API key from https://platform.openai.com/api-keys
2. Set the `OPENAI_API_KEY` environment variable in your Supabase Edge Functions settings
3. The functions will automatically use OpenAI when the key is available

**Note**: The application works without OpenAI API key by using fallback recipe generation and recognition.

## Usage Guide

### Getting Started

1. **Sign Up/Login**
   - Create an account with email and password
   - Or sign in with Google OAuth
   - Your profile will be automatically created

2. **Set Nutrition Goals**
   - Navigate to the Nutrition Tracker
   - Click "Edit Goals" to set your daily targets
   - Adjust calories, protein, carbs, and fat based on your objectives

3. **Generate a Recipe**
   - Go to "AI Generator"
   - Add ingredients you have (optional)
   - Select dietary preferences
   - Choose cuisine type and difficulty
   - Click "Generate Recipe"
   - Review and save the generated recipe

4. **Scan Ingredients**
   - Navigate to "Scan Ingredients"
   - Upload a photo of your ingredients
   - The AI will identify them
   - Add recognized ingredients to your inventory

5. **Browse Recipes**
   - Visit the "Recipes" section
   - Use search and filters to find recipes
   - Filter by cuisine type and difficulty
   - View detailed recipe information

6. **Plan Your Meals**
   - Open "Meal Plan"
   - Click the "+" button on any day/meal slot
   - Select a recipe from your collection
   - View the week's nutrition summary

7. **Manage Shopping List**
   - Go to "Shopping List"
   - Add items you need to buy
   - Check off items as you purchase them
   - Clear purchased items when done

8. **Track Nutrition**
   - Visit "Nutrition Tracker"
   - View your daily progress towards goals
   - See breakdown of calories, protein, carbs, and fat
   - Nutrition is automatically tracked from meal plans

## API Documentation

### Edge Functions

#### 1. Generate Recipe
**Endpoint**: `/functions/v1/generate-recipe`

**Method**: POST

**Request Body**:
```json
{
  "ingredients": ["chicken", "tomatoes", "garlic"],
  "dietaryPreferences": ["gluten-free", "dairy-free"],
  "cuisineType": "italian",
  "servings": 4,
  "difficulty": "medium",
  "maxPrepTime": 30
}
```

**Response**:
```json
{
  "success": true,
  "recipe": {
    "title": "Recipe Name",
    "description": "Brief description",
    "instructions": "Step-by-step instructions",
    "ingredients": [
      { "name": "chicken breast", "quantity": 500, "unit": "g" }
    ],
    "prepTime": 15,
    "cookTime": 30,
    "servings": 4,
    "nutrition": {
      "calories": 350,
      "protein": 35,
      "carbs": 20,
      "fat": 15
    },
    "cuisineType": "italian",
    "difficultyLevel": "medium",
    "tags": ["healthy", "quick"]
  }
}
```

#### 2. Recognize Ingredients
**Endpoint**: `/functions/v1/recognize-ingredients`

**Method**: POST

**Request Body**:
```json
{
  "image": "data:image/jpeg;base64,<base64-encoded-image>"
}
```

**Response**:
```json
{
  "success": true,
  "ingredients": ["tomatoes", "onions", "garlic"],
  "confidence": 0.95
}
```

## Security

### Authentication
- JWT-based session management
- Secure password hashing with Supabase Auth
- OAuth 2.0 integration with Google
- Automatic session refresh

### Data Protection
- Row Level Security (RLS) on all tables
- Users can only access their own data
- Recipes are public but can only be modified by creators
- All API endpoints require authentication

### Best Practices
- Environment variables for sensitive data
- HTTPS enforcement in production
- XSS protection with React
- SQL injection prevention with parameterized queries

## Development

### Available Scripts

- `npm run dev` - Start development server
- `npm run build` - Build for production
- `npm run preview` - Preview production build
- `npm run lint` - Run ESLint
- `npm run typecheck` - Run TypeScript type checking

### Code Style

- TypeScript for type safety
- Functional React components with hooks
- Tailwind CSS for styling
- ESLint for code quality
- Single responsibility principle for components

### Testing

To test the application:

1. Create a test account
2. Generate a recipe using the AI generator
3. Upload an ingredient photo for recognition
4. Create a meal plan for the week
5. Add items to the shopping list
6. Check nutrition tracking updates

## Troubleshooting

### Common Issues

**Issue**: AI features not working
- **Solution**: Check if OpenAI API key is set. The app will use fallback mode without it.

**Issue**: Authentication errors
- **Solution**: Verify Supabase credentials in `.env` file

**Issue**: Database connection errors
- **Solution**: Ensure Supabase project is active and accessible

**Issue**: Build errors
- **Solution**: Run `npm install` to ensure all dependencies are installed

## Performance Considerations

- Images are optimized for web delivery
- Lazy loading for large recipe lists
- Efficient database queries with proper indexes
- Edge Functions for serverless scalability
- Client-side caching for frequently accessed data

## Future Enhancements

- WebSocket integration for real-time cooking assistance
- Recipe sharing and social features
- Advanced meal planning with automatic shopping list generation
- Integration with grocery delivery APIs
- Mobile app with React Native
- Recipe import from URLs
- Cooking timer and step-by-step mode
- Meal prep suggestions
- Dietary restriction validation
- Recipe scaling and unit conversion

## Contributing

This project was created as a technical assignment to demonstrate:
- Full-stack development skills
- AI integration capabilities
- Modern web development practices
- Database design and security
- API development
- User experience design

## License

This project is created for educational and evaluation purposes.

## Contact

For questions or feedback about this project, please contact the repository owner.

---

**Built with** ❤️ **using React, TypeScript, Supabase, and OpenAI**
